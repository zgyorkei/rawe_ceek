# __APP_TITLE__

Made by `desktop-kit create` (desktop-kit's README, "A new app"). One app on every device: the web app on its
Vercel site, installed from Chrome as an app window on the PC and on the home screen of a phone. On a PC the app
window shows the desktop layout and does everything a desktop app does (desktop-kit's README, "The standard: the
Chrome app matches the desktop app"); what a browser cannot do runs in desktop-kit's local service on the PC.

| Part | Where |
| --- | --- |
| The page (Vite, React, react-router) | `index.html`, `src/` |
| The PWA (manifest, worker, install, update, navigation) | `pwa.config.ts`, `src/sw.ts`, from pwa-kit |
| The server routes (Vercel) | `api/index.ts`, `lib/api.ts` |
| The data (Firestore, Google sign-in) | `src/lib/firebase.ts`, `src/lib/notes.ts`, `firestore.rules`, from desktop-kit/sync |
| What runs on the PC (jobs, scrapers, keys of the PC) | `service/`, on desktop-kit's local service |
| The name, the title and the port | `app.config.ts` |

## Every day

```powershell
npm run dev
```

The page and the API on http://127.0.0.1:__APP_PORT__/ with hot reload. The port is this app's own (desktop-kit's
README, "Ports"): it never moves to another one, so the browser's storage, the installed app and the local service's
origins stay the same.

```powershell
npm run app
```

The app in its own window (Chrome, else Edge), 1400 x 900, in the desktop layout. `APP_URL` opens another address
(the Vercel site), `APP_ID` the installed app.

```powershell
npm run check
```

The type check, the tests and the web build (`dist/`). `npm run preview` serves the build on the same port.

## The kits

`desktop-kit` and `pwa-kit` are in `vendor/` as tarballs, pinned by `file:vendor/...` in `package.json`, because
Vercel clones only this repository. **This is temporary:** once the kits have release tags (DK.RELEASE), `package.json`
pins the tags instead, and `vendor/` and `scripts/kits-refresh.mjs` go. Until then, a newer kit is taken in by:

```powershell
npm run kits:refresh
npm install
```

It builds and packs the sibling checkouts `..\desktop-kit` and `..\pwa-kit` (`--desktop-kit <dir>`, `--pwa-kit <dir>`
or `DESKTOP_KIT_DIR`, `PWA_KIT_DIR` for others). Commit `vendor/`, `package.json` and `package-lock.json` together.

## The first setup, once

### 1. The Firebase project

1. In the Firebase console (https://console.firebase.google.com), add a project for __APP_TITLE__.
2. **Authentication** > Sign-in method: switch on **Google**.
3. **Firestore Database**: create the database (a region near you; production mode). For a named database rather than
   `(default)`, put its id in `VITE_FIREBASE_DATABASE_ID`.
4. **Firestore** > Rules: paste `firestore.rules` and publish. Each collection the app adds gets its own rules there
   (the notes' rules show how), and `ownRules()` lists it.
5. **Project settings** > Your apps: add a **web app**. Its config goes into `.env` (copy `.env.example`) as the
   `VITE_FIREBASE_*` values. That config is public by design: the rules guard the data.

### 2. The Vercel project

1. In Vercel, **Add New** > Project, and import this repository. The framework is Vite; `vercel.json` sends `/api/*`
   to `api/index.ts` and every other path to the page.
2. **Settings** > Environment Variables: the same `VITE_FIREBASE_*` values as in `.env`, and each server key
   (`EXAMPLE_API_KEY` and the ones the app adds) for Production and Preview. A server key is read at run time by
   `lib/api.ts`: it is never a `VITE_` variable, never in `src/` and never in the page.
3. Deploy. The site's address (such as `https://__APP_NAME__.vercel.app`) is the app's address from now on.

### 3. Google sign-in: the authorized domains

Firebase **Authentication** > Settings > **Authorized domains**: add the Vercel site's domain. `localhost` is there
already; add `127.0.0.1` for `npm run dev`. Firebase's Google sign-in makes its own OAuth client, so there is no client
of your own to set up. A preview deployment's domain is added only while it is tested.

### 4. The first install

Open the Vercel site in Chrome on the PC and choose **Install** (the button on This PC, or the install icon in the
address bar). On an Android phone, Chrome's menu > **Add to home screen**. From then on the app updates itself: a new
deployment shows the update line, and **Reload** takes it.

### 5. The local service, on each PC

Only if the app uses `service/` (a job at night, a scraper, a key that must stay on the PC). desktop-kit's README, "The
local service", sets the service itself up once per machine. Then, in the desktop-kit folder of that machine:

```powershell
node bin/desktop-kit-service.mjs services add C:\git_personal\__APP_NAME__\service\__APP_NAME__-daily.mjs
node bin/desktop-kit-service.mjs services add C:\git_personal\__APP_NAME__\service\__APP_NAME__-local.mjs
node bin/desktop-kit-service.mjs origins add https://__APP_NAME__.vercel.app
node bin/desktop-kit-service.mjs services on __APP_NAME__-daily
node bin/desktop-kit-service.mjs services on __APP_NAME__-local
```

The folder is where this repository is on that machine. Pages on `http://127.0.0.1:__APP_PORT__` need no `origins add`.

- **The daily job** (`__APP_NAME__-daily`) is leased: it runs only on the machine holding the app's lease. With the
  shared lease (the mini PC preferred, desktop-kit's README, "The shared lease") it runs once a day whichever PCs have
  it on. `node bin/desktop-kit-service.mjs lease` shows the setting.
- **The local service** (`__APP_NAME__-local`) answers on its own PC only. Its key comes from an environment variable
  the user sets once on that PC, never from a key store or a file:

  ```powershell
  [Environment]::SetEnvironmentVariable('__APP_ENV___LOCAL_KEY', '<the key>', 'User')
  ```

  The name is `KEY_VARIABLE` in the module. Restart the service (`stop`, then `start`) so it sees the new variable.

## The rules this app keeps

- Secrets are read at run time from the environment: `.env` here (never committed), Vercel's settings on the site, an
  environment variable on the PC for the local service.
- Links to other sites open in a Chrome tab (`src/components/ExternalLink.tsx`), never inside the app window.
- The navigation (`src/lib/nav.ts`, pwa-kit/nav) is a bar under 600 px, a rail from 600 and the expanded rail from
  1200; every quick action in `pwa.config.ts` is one of its routes (the tests check it).
