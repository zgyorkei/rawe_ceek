// A leased service of desktop-kit's local service (desktop-kit/service): a timed job that runs on the one machine
// holding the app's lease (the mini PC, else the user's PC), so it runs once a day however many PCs have it on.
// Added once on each machine (README, "The local service"); off until it is switched on there. The top level only
// defines: the module is imported only while the switch has it on.
import { defineService } from 'desktop-kit/service';

export default defineService({
  name: '__APP_NAME__-daily',
  app: '__APP_NAME__',
  kind: 'leased',
  description: 'the daily job of __APP_TITLE__',
  start(ctx) {
    /** @type {{ at: string, ok: boolean } | null} */
    let last = null;
    ctx.daily('04:00', async (signal) => {
      // the job's work goes here (a scraper through desktop-kit/scraper, a Firestore write through the service's
      // account); it stops when `signal` aborts
      if (signal.aborted) return;
      last = { at: new Date().toISOString(), ok: true };
      ctx.log.info('the daily job ran');
    }, { name: 'daily' });
    return {
      // GET http://127.0.0.1:47380/services/__APP_NAME__-daily/last
      http: (req, res, next) => {
        if (req.method !== 'GET' || req.url !== '/last') return next();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(last));
      },
    };
  },
});
