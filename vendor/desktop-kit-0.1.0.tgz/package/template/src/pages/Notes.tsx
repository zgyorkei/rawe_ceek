import { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router';
import type { User } from 'firebase/auth';
import { firebase, firebaseConfig, signIn, signOutOf, watchUser } from '../lib/firebase';
import { MAX_NOTE, addNote, deleteNote, watchNotes, type Note } from '../lib/notes';

export default function Notes() {
  const fb = firebase();
  const [user, setUser] = useState<User | null>(null);
  const [notes, setNotes] = useState<Note[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [params] = useSearchParams();
  const input = useRef<HTMLTextAreaElement>(null);

  useEffect(() => (fb ? watchUser(fb, setUser) : undefined), [fb]);
  useEffect(() => {
    if (!fb || !user) return undefined;
    return watchNotes(fb.db, user.uid, setNotes, (err) => setError(err.message));
  }, [fb, user]);
  // the quick action "New note" (pwa.config.ts) opens /notes?add=note
  useEffect(() => { if (params.get('add') === 'note') input.current?.focus(); }, [params]);

  if (!fb) return <section><h1>Notes</h1><p>Firebase is not set up: {firebaseConfig().problem}.</p></section>;
  if (!user) {
    return (
      <section>
        <h1>Notes</h1>
        <button type="button" onClick={() => void signIn(fb).catch((err: Error) => setError(err.message))}>Sign in with Google</button>
        {error && <p role="alert">{error}</p>}
      </section>
    );
  }
  return (
    <section>
      <h1>Notes</h1>
      <p>
        Signed in as {user.email} <button type="button" onClick={() => void signOutOf(fb)}>Sign out</button>
      </p>
      <form onSubmit={(e) => { e.preventDefault(); addNote(fb.db, user.uid, text); setText(''); }}>
        <textarea ref={input} value={text} maxLength={MAX_NOTE} onChange={(e) => setText(e.target.value)} aria-label="A new note" />
        <button type="submit" disabled={!text.trim()}>Add</button>
      </form>
      {error && <p role="alert">{error}</p>}
      <ul className="notes">
        {notes.map((n) => (
          <li key={n.id}>
            <span>{n.text}</span>
            <button type="button" onClick={() => deleteNote(fb.db, user.uid, n.id)} aria-label="Delete the note">Delete</button>
          </li>
        ))}
      </ul>
    </section>
  );
}
