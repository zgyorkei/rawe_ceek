import { addDoc, collection, deleteDoc, doc, onSnapshot, orderBy, query, serverTimestamp } from 'firebase/firestore';
import { saved } from 'pwa-kit/offline';
import type { Db } from 'desktop-kit/sync';

// The template's one piece of data, to show the pattern: users/{uid}/notes/{id}, each stamped with the server's time
// (firestore.rules). Offline, a write waits in Firestore's cache and goes when the connection is back; pwa-kit's
// saved() turns a write the server refuses into the page's refusal line.

export interface Note {
  id: string;
  text: string;
}

export const MAX_NOTE = 2000;

export function watchNotes(db: Db, uid: string, listener: (notes: Note[]) => void, onError: (err: Error) => void): () => void {
  const q = query(collection(db, 'users', uid, 'notes'), orderBy('updatedAt', 'desc'));
  return onSnapshot(
    q,
    (snap) => listener(snap.docs.map((d) => ({ id: d.id, text: String(d.get('text') ?? '') }))),
    onError,
  );
}

export function addNote(db: Db, uid: string, text: string): void {
  const clean = text.trim().slice(0, MAX_NOTE);
  if (!clean) return;
  void saved(addDoc(collection(db, 'users', uid, 'notes'), { text: clean, updatedAt: serverTimestamp() }));
}

export function deleteNote(db: Db, uid: string, id: string): void {
  void saved(deleteDoc(doc(db, 'users', uid, 'notes', id)));
}
