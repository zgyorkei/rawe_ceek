# desktop-kit

The desktop pieces the personal apps share, in one library, so each piece is
written and fixed once. Each part is its own subpath export: an app imports
only the parts it uses, and a part it never imports is never loaded.

Used by the desktop builds of SmakMal (SM.DESKTOP), Brick Tracker
(lego-tracker's `desktop` package) and BrickBudget (budget-tracker).

## Parts

| Import | Holds | State |
| --- | --- | --- |
| `desktop-kit` | `inElectron()`: whether the code runs in an Electron process | here |
| `desktop-kit/google-signin` | the desktop Google sign-in (PKCE on a loopback port) and the kept Google session | here |
| `desktop-kit/shell` | the Electron shell around a web app: the loopback server, the main window, the app-only IPC, the setup window scaffold, the dev start, an opt-in tray | here |
| `desktop-kit/packaging` | the Windows installer build (NSIS) with the installed 7-Zip 26.03+, the web build and package guards, the Squirrel stub | here |
| `desktop-kit/store` | the local-first copy on this PC: atomic files, one folder per Google account, daily backups, the guard against an empty copy over a full one | here |
| `desktop-kit/drive` | the Google Drive app-folder mailbox's client and layout, browser-safe (the desktop and its website share it) | here |
| `desktop-kit/drive/desktop` | the desktop's side of the mailbox: the publisher, the inbox and the worker that runs them (removed once LEGO Tracker is off it, docs/sync-plan.md D4) | here |
| `desktop-kit/sync` | the standard sync, browser-safe: Firestore opened with its offline copy on disk, changes not sent yet, refused changes kept, batched writes, copies, the backup feed | here |
| `desktop-kit/sync/jobs` | the desktop's background services as jobs through Firestore: heartbeat, claim, delegate, the daily job | here |
| `desktop-kit/sync/migrate` | the one-time move of an app's stored data into Firestore, after a copy of the data as it was | here |
| `desktop-kit/sync/desktop` | the local backup on each PC (main process), keyed by store and account, and its IPC | here |
| `desktop-kit/update` | the app's updates without code signing (main process): electron-updater on the app's own feed, a check at start and once a day, the user asked before any download, installed when the app quits and never sooner; on macOS, "a newer version is available" | here |
| `desktop-kit/update/server` | the feed on the app's own site (a Vercel function or an Express route): only the signed-in owner, each file handed over by a short-lived link into private storage | here |
| `desktop-kit/scraper` | the one Playwright scraping module (main process): each shop in the browser its rule names (the installed Chrome or Edge, or the Chromium the installer ships), one page at a time at a person's pace, bot checks and cookie banners waited out, one result shape, errors that name the shop and the reason | here |
| `desktop-kit/service` | the local service the Chrome apps call on 127.0.0.1 (plain node from this repository, started at sign-in): services registered by name and switched on per machine, leased (timed jobs, scrapers) or local, the health route, the origin list | here |

A new part gets its entry in `tsup.config.ts` and in the `exports` map of
`package.json` when it lands, never as an empty stub.

Beside the parts, `template/` and the `desktop-kit create` command make a new app
(below, "A new app"); they are no import of their own.

Electron is a peer dependency, optional: the parts that use it import the
app's own Electron, and the parts that do not need none installed.

## Google sign-in (`desktop-kit/google-signin`)

Main process only: the client secret and the tokens never leave it, and the
part logs nothing. Google refuses OAuth inside an embedded browser such as
Electron's, so the consent screen opens in the user's own browser, the code
comes back to a one-off port on 127.0.0.1, and PKCE (S256) protects it. A
callback with the wrong state (another local page) is refused with 400 and the
sign-in keeps waiting. The ID token it yields is what a renderer signs in to
Firebase with (`signInWithCredential`).

The part imports no Electron: the app passes `shell.openExternal` and
`safeStorage`.

```ts
import { app, safeStorage, shell } from 'electron';
import path from 'node:path';
import { DRIVE_APPDATA_SCOPE, GoogleSession, loadOAuthClient } from 'desktop-kit/google-signin';

const google = new GoogleSession({
  productName: 'Brick Tracker',                      // the browser page's text
  file: path.join(app.getPath('userData'), 'google-session.bin'),
  client: () => loadOAuthClient(path.join(app.getPath('userData'), 'oauth-client.json')),
  secrets: safeStorage,
  openBrowser: (url) => shell.openExternal(url),
  scopes: [DRIVE_APPDATA_SCOPE],                     // extra scopes, asked by a kept sign-in
});
app.whenReady().then(() => google.load());

const idToken = await google.signIn();                // keep: false asks only who the user is, and keeps nothing
const fresh = await google.idToken();                 // a fresh ID token for Firebase, or null
```

- **The kept session**: with `keep` (the default) the sign-in asks for the
  extra scopes and offline access, and the refresh token is kept encrypted
  with `safeStorage` in `file`. When Google sends no new refresh token for the
  same account, the kept one stays. `accessToken()` is for the main process.
- **When it ends by itself**: a refused refresh (`SessionRevokedError`) or an
  unreadable file drops the session and leaves a marker (`ended()`:
  `{ at, why: 'refused' | 'unreadable' }`, in `<file's name>-ended.json`) until
  the next sign-in or sign-out, so the app can say so after a restart;
  `onChange` tells it.
- **Signing out**: `forget()` drops the session on this PC. It does not revoke
  it at Google unless `revokeOnForget` is set: Google ties consent to the Cloud
  project, so a revoke also cuts the same account's access from the app's
  website and other PCs.
- **Cancelling**: a new `signIn()` cancels the one open, and `cancel()` ends it
  (`SignInCancelledError`, as when the user cancels on Google's screen).
- The pieces alone: `googleSignIn`, `refreshGoogleTokens`, `parseOAuthClient`
  and `loadOAuthClient` (a "Desktop app" or web client JSON; the secret is
  optional, the endpoints read from it), `claimsOf`.

## The shell (`desktop-kit/shell`)

What an Electron shell around a web app needs. Electron is passed in
(`import * as electron from 'electron'`), never imported, so the module also
loads in plain Node: the dev start script and the tests use it there.

```ts
import * as electron from 'electron';
import path from 'node:path';
import { appIpc, appOrigin, createMainWindow, devProfile, secretPath, showWindow, singleInstance, startLocalServer } from 'desktop-kit/shell';

const { app } = electron;
const profile = devProfile({ packaged: app.isPackaged, env: process.env, prefix: 'SMAKMAL', port: 47331 });
if (profile.userData) app.setPath('userData', profile.userData);
const origin = appOrigin(profile.port);
const secret = (name: string) => secretPath(name, { packaged: app.isPackaged, userData: app.getPath('userData'), devDir: path.join(__dirname, '..'), devProfile: !!profile.userData });

let win: electron.BrowserWindow | null = null;
if (singleInstance(app, () => showWindow(win))) {
  app.whenReady().then(async () => {
    await startLocalServer({ port: profile.port, webDir: path.join(process.resourcesPath, 'web'), api: myExpressApp });
    const ipc = appIpc(electron.ipcMain, origin);
    ipc.handle('auth:google', () => google.signIn());   // answers only the app's own page
    win = createMainWindow(electron, { origin, preload: path.join(__dirname, 'preload.cjs'), title: 'SmakMal' });
  });
}
```

- **The loopback server** (`startLocalServer`): the built web app and the app's
  API on 127.0.0.1 only, at a fixed port, since the page's origin keys its
  Firebase session and storage. The API is a connect-style handler mounted on
  `/api` (an express app is one); a request it does not answer is a JSON 404,
  never the page. A route of the app (no extension) gets the page, a missing
  asset a 404, and nothing outside the web folder is ever served.
- **The main window** (`createMainWindow`): sandboxed, context-isolated, no
  Node in the page. Links and navigation off the app's origin open in the
  user's browser (http and https only) and nothing opens another window
  (`guardNavigation`). Opt-in: `hideOnClose` for a tray app,
  `backgroundThrottling: false` for a page's scheduled work while hidden.
- **The app's channels** (`appIpc`): `handle`, `on` and `sync`, each answering
  only the app's own page, compared as parsed origins, not as a prefix
  (`assertFromApp`).
- **One instance** (`singleInstance`): a second start focuses the first.
- **The setup window** (`openSetupWindow`): a small window whose page only
  collects text. The app gives the page, its preload and the channels, each
  handler checking what the page sends; only that window may call them, it
  cannot navigate, and it resolves with what was saved, or null when closed.
  `saveSettingsFile` writes a settings file in the data folder atomically.
- **Secret files** (`secretPath`): from the data folder when packaged (or in a
  dev run with its own profile), from the dev folder otherwise. Secrets are
  never packaged. `devProfile` reads a dev run's `<PREFIX>_USER_DATA` and
  `<PREFIX>_PORT`, so it runs beside the installed app.
- **The dev start** (`runElectron`, an app's `run.mjs`): Electron on the app
  folder, without `ELECTRON_RUN_AS_NODE` (VS Code terminals export it, and it
  makes Electron exit silently as plain Node); a debugging port or an
  inspector argument is refused.

  ```js
  import { runElectron } from 'desktop-kit/shell';
  process.exit(await runElectron({ appDir: import.meta.dirname, args: process.argv.slice(2) }));
  ```
- **Opt-in, off unless the app asks**: the tray (`createTray`, with a
  "Start with Windows" checkbox for packaged apps, `setStartWithWindows`,
  `startsWithWindows`, `trayTooltip`) and the hidden start (`HIDDEN_ARG`,
  `startedHidden`). SmakMal wants a plain window.

What the two apps did differently, and what the kit keeps:

| | Brick Tracker (lego-tracker) | BrickBudget (budget-tracker) | The kit |
| --- | --- | --- | --- |
| Page | served on a fixed loopback port | `file://` or the Vite dev server | the loopback server |
| IPC | every channel checks the sender | no sender checks | every channel checks the sender, by origin |
| Close | hides to the tray, always | hides only in background mode; otherwise waits for the page's exit tasks (a Sheets sync, 15 s at most) | `hideOnClose` opt-in; exit tasks stay the app's |
| Tray | always | only in background mode | opt-in |
| Windows notifications | | `setAppUserModelId` | the app's (one line) |

## Packaging (`desktop-kit/packaging`)

For the app's build script (Node), never the app. The Windows installer with
electron-builder: NSIS, one click (or assisted, below), for the current user,
no admin rights,
never code-signed (the user's decision: a signing variable in the
environment is dropped, with a line saying so). electron-builder and
`@electron/asar` are the app's own dev dependencies, loaded from its folder.

```js
import { buildInstaller, forbiddenValuesFrom } from 'desktop-kit/packaging';

await buildInstaller({
  projectDir: desktopDir,
  productName: 'SmakMal',
  appId: 'com.zgyorkei.smakmal',
  setupName: 'SmakMal-Setup.exe',                 // the fixed name a download link points at
  icon: path.join(desktopDir, 'dist', 'icon.ico'),
  files: ['dist/**/*', 'package.json'],           // an allow-list; the secret names are always excluded too
  asarUnpack: ['**/*.node'],                       // native modules cannot load from inside app.asar
  extraResources: [{ from: webStage, to: 'web' }],
  secretNames: ['.env', 'oauth-client.json', 'app-config.json', 'google-session.bin'],
  secretFiles: [path.join(desktopDir, '.env'), path.join(desktopDir, 'oauth-client.json')],
  web: { dir: webStage, forbidden: forbiddenValuesFrom({ configFiles: [firebaseConfig], envNames: ['VITE_FIREBASE_PROJECT_ID'] }) },
  // startWithWindows: true,                      // opt-in: start with Windows, hidden, on a fresh install
  // installer: 'assisted',                      // opt-in: setup pages and a finish page; 'oneClick' by default
});
```

- **7-Zip**: only the installed one, `SEVENZIP_PATH` or
  `C:\Program Files\7-Zip\7z.exe`, version-checked (`7z i`) and refused below
  26.03; a `7za.exe` or a copy inside `node_modules` is refused outright. It is
  passed as `ELECTRON_BUILDER_7ZIP_PATH`, and the `toolsets` (NSIS 1.2.1,
  winCodeSign 1.1.0) come as .tar.gz and .zip, so no 7z-packed download is
  involved. The compression level is 7 (9 needs more memory than a busy
  machine has).
- **The web build guard**, before anything is built: no Google API key, no
  Google client id and none of the forbidden values (the builder's own
  Firebase project) in any file of the web build; every install gets its
  own at run time.
- **The package guard**, before the installer is made: no secret file by
  name inside `app.asar` or beside it, and no secret value (the Google API
  keys and OAuth client secrets in the app's secret files, and any value
  given) in `app.asar` or the unpacked files. When one is found, the build is
  discarded.
- **A build folder per build** (`release/<version>-<stamp>`), since
  overwriting fails whenever something still holds a file open; the old ones
  are removed best-effort afterwards.
- **Start with Windows** on a fresh install is opt-in (`startWithWindows`,
  desktop-kit's `installer/start-with-windows.nsh`, the same Run value the
  shell's `setStartWithWindows` writes). An app with its own include passes
  `nsisInclude` and may `!include` the kit's file.
- **The installer's kind** (`installer`): `'oneClick'`, the default, installs
  without a page and starts the app when it ends. `'assisted'` shows a welcome
  page, the install mode (only for the current user: the all-users choice needs
  an administrator, and none is asked for), the install folder, the progress,
  and a finish page whose "Run <app>" box starts unticked, so the app starts
  only when the user ticks it. It stays a per-user install, the data folder is
  kept on an uninstall as before, and the uninstaller takes electron-builder's
  assisted pages with it. The welcome page and the unticked box come from
  desktop-kit's `installer/assisted.nsh` (with start with Windows,
  `assisted-start-with-windows.nsh`, which includes both); an app with its own
  include may `!include` it.

**The Squirrel stub.** electron-builder depends on electron-winstaller
(Squirrel.Windows), which vendors 7-Zip 16.04; the apps build NSIS only, so
an app replaces it with desktop-kit's stub (`stubs/electron-winstaller`, which
throws if anything loads it), and `buildInstaller` refuses to run while the
real one is installed. In the app's desktop `package.json`:

```json
"devDependencies": { "electron-winstaller": "file:../../desktop-kit/stubs/electron-winstaller" },
"overrides": { "electron-winstaller": "$electron-winstaller" }
```

That path is right while the kit is linked from the sibling folder. npm reads
a `file:` dependency before it installs anything, so once the app pins a
release it cannot point inside `node_modules/desktop-kit`: it keeps its own
copy of the two files (`stubs/electron-winstaller` in the app) and points the
same two lines at that.

How the two apps packaged, and what the kit keeps:

| | Brick Tracker (lego-tracker) | BrickBudget (budget-tracker) | The kit |
| --- | --- | --- | --- |
| Tool | electron-builder NSIS installer | `@electron/packager`, then a zip by PowerShell | electron-builder NSIS |
| 7-Zip | the installed one, 26.03+ | none (no installer) | the installed one, 26.03+ |
| Files | an allow-list | a deny-list | an allow-list, secret names out besides |
| Native modules and Playwright | unpacked | unpacked | `asarUnpack`, `**/*.node` by default |
| Guards | the web build and the package | none | both |
| Build folder | one per build | overwritten | one per build |
| Signing | none | none | none, by decision |

## The store (`desktop-kit/store`)

Main process only, from lego-tracker's `desktop/src/store`. The app's data
lives on this PC, one folder per Google account (`<root>/<sub>/`, the account
id checked before it names a folder), and the app's own reducer decides what
the data is: the kit keeps the files.

```ts
import { AccountStore } from 'desktop-kit/store';

const store = new AccountStore<MyState>({
  root: path.join(app.getPath('userData'), 'accounts'),
  empty: () => ({ version: 1, items: {} }),
  load: (raw) => migrate(raw), // null for a file the app cannot read
  count: (s) => Object.keys(s.items).length,
  noun: 'items',
  warn: (m) => log.warn(m),
});
await store.open(session.account()!.sub);
store.commit({ state: reduce(store.state, op), changed: [op.id] });
app.on('before-quit', () => store.flushSync());
```

- **Atomic files** (`writeFileAtomic`, `writeFileAtomicSync`): a temporary
  file, flushed, then renamed over the old one; the rename is retried while
  Windows holds the file (`EPERM`, `EBUSY`, `EACCES`). The session file of
  `desktop-kit/google-signin` is written by the same function.
- **A broken file is kept** (`readJsonFile`): moved aside as
  `<name>.corrupt-<ts>` and reported through the app's `warn`, never lost.
- **Written after a quiet moment** (1 s by default), and synchronously by
  `flushSync()` as the app quits; switching account writes the open one first.
- **One backup a day** (`backup/state-<day>.bak`, the newest 7), made before
  the day's first write.
- **No empty copy over a full one**: a write that would replace N items with
  none is refused and reported ("Did not replace the copy of N items on this
  PC with an empty one."), unless the commit says the user emptied it
  (`{ emptied: true }`).
- **Change events** (`'change'`, coalesced, 150 ms by default) carry the ids
  changed and removed and the store's status (written when, the backup day,
  the last error), so a refused write reaches the page too.
- **Side files** (`readSide`, `writeSide`, `setAside`, `run`): files beside
  the copy (lego-tracker's price history), always inside the account folder,
  written one task at a time; a removed one goes to `removed/`.

The IPC between the store and the page is the app's own, on the shell's
`appIpc`.

## The Drive mailbox (`desktop-kit/drive`, `desktop-kit/drive/desktop`)

From lego-tracker's `lib/drive` and `desktop/src/drive`: the desktop and the
app's website (or a phone) share the account's Drive app-data folder
(`drive.appdata`, private to the app; the user never sees it in Drive). One
writer per file kind:

| File | Writer | What it is |
| --- | --- | --- |
| `snapshot.json.gz` | the desktop | the copy as the app publishes it, the batches applied and the ops refused |
| `status.json` | the desktop | the heartbeat (every 2 min): which PC publishes, its mode and version |
| `<prefix><id>.json.gz` | the desktop | one thing's detail, loaded lazily (lego-tracker: `history-<setId>.json.gz`) |
| `reply-<requestId>.json` | the desktop | how a request the website made went |
| `ops-<ts>-<batchId>.json` | the website | a batch of changes |

- **Applied once**: the inbox (every 15 s) checks each batch with the app's
  validator, applies it through the app's reducer, publishes the snapshot
  naming the batch, then deletes the file. A batch already named is only
  deleted, and the applied ids are kept on disk (`drive.json` in the account
  folder), so a retried batch never applies twice. A website overlays any
  batch not yet named on the snapshot it has.
- **One publisher**: a PC pauses while another's heartbeat is fresh (under
  5 min) and takes over when it goes stale; a wiped folder is published again
  from scratch.
- **The protocol's fields win**: the snapshot is the app's payload with
  `version`, `publisher`, `mode`, `applied`, `rejected` and the detail
  summary written over it.

The app gives the mailbox its copy as a `MailboxSource` (an `AccountStore`
gives the account half), its validator as a `BatchCheck`, and runs it with a
`DriveWorker` over desktop-kit's `GoogleSession`:

```ts
import { DriveWorker } from 'desktop-kit/drive/desktop';

const worker = new DriveWorker(source, session, {
  settings: () => ({ drive: settings.drive, mode: 'local' }),
  validate: validateOpBatch,
  selfFile: path.join(app.getPath('userData'), 'drive-publisher.json'),
  appVersion: app.getVersion(),
  detailPrefix: 'history-',
  detailsKey: 'history',
});
worker.on('status', (s) => send('drive:status', s));
worker.on('request', (r) => runRequest(r).then(() => worker.reply(r.requestId, 'done')));
```

`desktop-kit/drive` (the client, the layout, the page's status types) runs in
a browser too, so the website reads the same layout. Who uses which part:

| App | Store | Drive mailbox |
| --- | --- | --- |
| Brick Tracker (lego-tracker) | yes, its sets and price history | yes, with its website |
| BrickBudget (budget-tracker) | no | no: its Drive use is a Google Picker link to one Sheets file the user sees (`drive.file`), and its gift-registry page is published to a git repository |
| SmakMal | no (Firestore's own copy on disk) | no |

## Sync (`desktop-kit/sync`, `/sync/jobs`, `/sync/migrate`, `/sync/desktop`)

The standard every app follows (docs/sync-plan.md, approved 2026-11-15):

- **Firestore is the store of record, and every device writes it directly.** That means the phone, the website and
  the desktop's page.
- **Changes made offline are queued by Firestore itself**, in its offline copy on disk.
- **Nothing waits for a desktop.** The desktop's background services are jobs that only the job waits for.
- **Every PC keeps a daily backup file.**

Each app has its own Firebase project, except that SmakMal shares one with acn-ultra-balaton, each with its own
database. So everything the kit keeps per store is keyed by project and database (`storeOf`, `storeKey`,
`storeFolder`).

**The app passes its own Firestore module** (`import * as firestore from 'firebase/firestore'`, typed `FirestoreApi`).
The kit only imports Firebase's types, so a bundle never holds two copies of the SDK. Two copies refuse each other's
references.

### The page: phone, website and the desktop's window

```ts
import * as firestore from 'firebase/firestore';
import { initializeApp } from 'firebase/app';
import { openFirestore, parseFirebaseConfig, storeOf, storeKey, PendingWrites, OutcomeLog, outcomeKey, sendWrite, stamped } from 'desktop-kit/sync';

const config = parseFirebaseConfig(runtimeConfig);           // app-config.json on the desktop, build variables on the website
const db = openFirestore(firestore, initializeApp(config), { databaseId: config.firestoreDatabaseId });
const store = storeOf(config);

const pending = new PendingWrites();                         // "N changes not sent yet"
void pending.start(firestore, db);                           // what an earlier session queued
pending.onChange((n) => setNotSent(n));
const outcomes = new OutcomeLog({ key: outcomeKey(storeKey(store), uid) });   // refusals, kept on disk

// one document per thing a person edits; one field-level update, stamped with the server's time
const ref = firestore.doc(db, 'users', uid, 'entries', entry.id);
sendWrite(firestore.updateDoc(ref, stamped(firestore, { amount: 120 })), { what: 'Amount of Rent, March', path: ref.path }, { pending, outcomes });

// listeners report their documents' local changes
firestore.onSnapshot(entriesQuery, { includeMetadataChanges: true }, (snap) => {
  pending.observe('entries', snap);
  render(snap.docs);
});
```

- **`openFirestore`** opens Firestore with `persistentLocalCache` and the multi-tab manager, on the named database.
  `cache: 'memory'` is only for where a copy on disk is unwanted.
- **`PendingWrites`** counts what this device changed and Firestore has not confirmed: the documents shown with local
  changes, the writes in flight, and what an earlier session queued. These are never added together; the largest
  wins. The count goes to zero as soon as the device is online, whether or not a desktop runs.
- **`sendWrite`** sends a write without waiting for it (offline, it settles only when the device is online again).
  A refusal goes to the `OutcomeLog`, which keeps it in localStorage so the reason survives a reload:
  - an edit to something deleted elsewhere: `deleted-elsewhere`, from `not-found`
  - a write the rules refused: `refused`

  A page closed before Firestore answers never hears the answer. The log holds what this page heard.
- **`commitWrites`** commits a change that touches several documents (copies into later months, cooking that uses
  several items) as batches of at most 400. A failed batch rejects with `written`: what the batches before it wrote.
  Copies get ids derived from the change, and amounts change with `increment()` or a transaction.
- **`readCopy`** reads an account's data from the server, never from the offline copy, because offline a plain read
  can answer partly or wholly empty. `downloadCopy` saves it as JSON ("Download a copy"). `restoreBatch` turns a
  backup into the writes that make the store hold exactly it.

### The local backup on each PC

The desktop's page feeds the backup from the listeners it already has, so it costs no extra reads. The main process
keeps it with `desktop-kit/store`'s `AccountStore`.

```ts
// page (desktop only), once Firebase Auth has signed the user in
import { BackupFeed } from 'desktop-kit/sync';
const uid = auth.currentUser!.uid;                          // the Firebase Auth uid the rules check, not the Google sub
await window.backup.open(uid);                              // this account's backup on this PC
const feed = new BackupFeed({
  source: { ...store, uid },
  collections: [`users/${uid}/entries`, `users/${uid}/wishlist`],
  docs: [`kitchens/${kitchenId}`],
  send: (copy) => window.backup.put(copy),                  // the preload's backupBridge
});
firestore.onSnapshot(entriesQuery, { includeMetadataChanges: true }, (snap) => feed.collection(`users/${uid}/entries`, snap));

// preload
import { backupBridge } from 'desktop-kit/sync';
contextBridge.exposeInMainWorld('backup', backupBridge((channel, ...args) => ipcRenderer.invoke(channel, ...args)));

// main
import { BackupWriter, handleBackupIpc } from 'desktop-kit/sync/desktop';
const backup = new BackupWriter({ root: path.join(app.getPath('userData'), 'backup'), store: storeOf(config) });
handleBackupIpc(appIpc(electron.ipcMain, origin), backup);   // the page opens the account (window.backup.open)
backup.on('held', (h) => askUser(`The newest copy would drop ${h.removed} of ${h.total}. Keep it?`));
app.on('before-quit', () => backup.flushSync());
```

- **What it sends:** only answers from the server count; a snapshot `fromCache` is ignored. Nothing is sent until
  every named collection and document has had one server answer, and then the whole copy is sent after a quiet
  moment (10 s).
- **Which account:** the Firebase Auth uid, one id end to end: the feed tags each copy with it, the page opens the
  backup with it, and it names the folder. Only a uid safe as a folder name opens (1 to 128 letters, digits, - or _,
  never a Windows device name); Google sign-in's are 28 letters and digits.
- **Where it is kept:** `<userData>/backup/<project>~<database>/<uid>/`, holding:
  - `state.json`: the newest copy
  - `backup/state-<day>.bak`: one a day, the newest 7
  - `backup/before-<label>-<stamp>.json`: kept for good (`saveNamed`), for a restore or a migration

  AccountStore's rules apply: atomic writes, a broken file set aside, no empty copy over a full one.
- **What it refuses:** a copy from another project, database or account.
- **What it holds:** a copy that drops more than max(3, 10%) of the documents, or all of them, is held until the
  user confirms it (`confirmHeld`) or keeps the backup (`dropHeld`).
- **It is a backup, not a working copy.** To restore:
  1. `saveNamed('before-restore', await readCopy(...))`
  2. `commitWrites(firestore, db, restoreBatch(firestore, db, current, chosen))`

### Background services as jobs (`desktop-kit/sync/jobs`)

LEGO Tracker's handshake, made general:
1. The desktop writes a heartbeat to `<status>/{uid}`.
2. A page writes a pending job to `<jobs>/{id}`, as `{userId, kind, status, requestedAt, ...payload}`.
3. One desktop claims it in a transaction, runs it, and marks it `done` or `failed`.
4. A page that is not answered in time cancels the job and goes its own way.

A desktop whose services are switched off on that machine (`enabled`) neither beats nor claims, so pages never wait
for it. When the switch changes, start `serve` again.

```ts
import { createJobs } from 'desktop-kit/sync/jobs';
const jobs = createJobs<{ setIds: string[] }>(firestore, db, { jobsCollection: 'refreshRequests', appVersion });
const stop = jobs.serve(uid, (job) => refresh(job.kind, job.setIds), { enabled: () => servicesOn() });   // desktop
const outcome = await jobs.delegate(uid, 'prices', { setIds }, lastSeenAt);                              // page: 'done' | 'failed' | 'unavailable'
await jobs.scheduleDaily(uid, today, 'prices', { setIds });                                              // once a day, whichever desktops are on
```

LEGO Tracker keeps its collection names (`desktopStatus`, `refreshRequests`) and its payload (`setIds`), so its
rules stay as they are.

### The one-time move (`desktop-kit/sync/migrate`)

`migrateOnce(name, ports)` runs these steps in order, and each one stops the move when it fails:
1. **Marker:** if this PC or another already made the move, there is nothing to do.
2. **The copy as it was:** saved, and read back equal. Nothing is written to Firestore before this holds.
3. **Upload:** in batches.
4. **Check:** what was written is read back from the server and checked with the app's `check`, for example counts
   and sums. A failed check deletes what was written.
5. **Marker:** written last, with the document count and the source's SHA-256.

Two PCs may run the move at once. A step that fails reads the marker again before it deletes anything: when another
PC's marker is there (the rules refuse a second one), the move is done (`already`) and the documents stay. It deletes
what it wrote only when the server shows no marker, and nothing when the marker cannot be read.

`firestorePorts` gives the Firestore half of the ports. The app gives the old store's half: `readSource`, `saveCopy`,
`readCopy`, `toDocs` and `check`.

Under the rules below, each document carries `updatedAt: serverTimestamp()`. Compare with
`sameDocs(docs, back, { ignore: ['updatedAt'] })`, and add the app's own sums on top.

A restore restamps those fields the same way (`restoreBatch(..., { restamp: ['updatedAt'] })`, the default).

### Rules (a template for each app to adapt)

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    function signedIn() { return request.auth != null; }
    function isOwner(uid) { return signedIn() && request.auth.uid == uid; }
    function stamped() { return request.resource.data.updatedAt == request.time; }

    // the account's data: one document per thing a person edits, stamped with the server's time
    match /users/{uid}/{coll}/{id} {
      function isMarker() { return coll == 'meta' && id == 'migration'; }
      allow read: if isOwner(uid);
      allow create, update: if isOwner(uid) && !isMarker() && stamped();
      allow delete: if isOwner(uid) && !isMarker();
      // the migration marker: written once, never changed, so a second PC never uploads again
      allow create: if isOwner(uid) && isMarker();
    }

    // jobs (desktop-kit/sync/jobs)
    match /desktopStatus/{uid} {
      allow get, delete: if isOwner(uid);
      allow create, update: if isOwner(uid) && request.resource.data.keys().hasOnly(['lastSeenAt', 'appVersion']);
    }
    match /desktopJobs/{id} {
      function valid(d) {
        return d.status in ['pending', 'running', 'done', 'failed', 'cancelled'] && d.requestedAt is string;
      }
      allow get: if signedIn() && (resource == null || isOwner(resource.data.userId));
      allow list: if isOwner(resource.data.userId);
      allow create: if isOwner(request.resource.data.userId) && valid(request.resource.data) && request.resource.data.status == 'pending';
      allow update: if isOwner(resource.data.userId) && request.resource.data.userId == resource.data.userId && valid(request.resource.data);
      allow delete: if isOwner(resource.data.userId);
    }
  }
}
```

Each app checks its own fields and payload on top. Rules are published in the Firebase console (Firestore > Rules).

## The scraper (`desktop-kit/scraper`)

Main process only, from BrickBudget's `electron/productLookup.cjs` and Brick
Tracker's `desktop/src/scraper/engine.ts` (APPS.SCRAPER). The app keeps what
it reads off a page (shop-teacher's recipes, its own extractor); the kit
starts the browser, opens the page and hands it over. `playwright-core` is the
app's own (an optional peer dependency), loaded on the first launch, never when
the part is imported.

```ts
import { Scraper, useBundledChromium, isScraperError } from 'desktop-kit/scraper';

useBundledChromium(path.join(process.resourcesPath, 'ms-playwright')); // packaged app only; false in development
const scraper = new Scraper({
  profileRoot: path.join(app.getPath('userData'), 'scraper'),
  browsers: { default: ['chrome', 'msedge'], shops: [{ match: /(^|\.)amazon\.[a-z.]+$/, use: ['bundled'], name: 'Amazon' }] },
  locale: 'en-US',
});
const result = await scraper.scrape(url, ({ page }) => page.evaluate(readProduct), { consent: '#onetrust-accept-btn-handler' });
// { shop, url, title, price, currency, image, source }; or a ScraperError: isScraperError(e, 'blocked')
app.on('before-quit', () => void scraper.close());
```

- **The browser per shop** (`browsers`): a list tried in order, `'chrome'` and
  `'msedge'` (the installed ones, by Playwright's channel) or `'bundled'` (the
  Chromium the installer ships: Amazon served its 503 page to the installed
  Chrome). A rule matches a host by a RegExp, or by a domain and its
  subdomains. The default is BrickBudget's: Chrome, Edge, then a bundled one.
  A browser that failed to start is skipped for a minute (`launchRetryMs`), so
  the jobs behind it fail at once rather than each waiting out a launch.
- **Started by Playwright over its pipe only.** A debugging port or an
  inspector flag among `args` is refused (`launchArgs` throws). The window is
  real and parked off-screen (Cloudflare never cleared in headless mode), with
  no automation tells; `revealWindow(page)` brings it on-screen for the user
  to get past a consent wall or an "are you human" check.
- **One job at a time** (`withPage`, `scrape`), across every browser: a
  profile can be open only once, and one page at a time is a person's pace. A
  newcomer hears that it waits (`report`); `waiting` counts the queue. Each job
  has a limit (`timeouts.jobMs`, 4 minutes; `limitMs` per job): past it the job
  is given up (`'timed-out'`) and the browsers closed, so one that stopped
  answering cannot hold up the rest. The browsers close after 2 minutes idle
  (`idleCloseMs`; 0 closes them after every job, BrickBudget's way).
- **Opening a page** (`session.open`, `openPage`): a person-paced gap first
  (`pace`, 1.5 to 3.5 s), then the load; a Cloudflare challenge waited out; with
  `realPageMinChars` (BrickBudget: 200), a near-empty bot check page waited for
  until it reloads into the page; the cookie banner's button clicked (a
  selector, or the app's own step such as shop-teacher's `acceptConsent`); then
  `'bot-check'`, `'blocked'` (a captcha, Akamai's block page, the app's own
  `blocked` check) or `'http-error'` (a 5xx or 403 no challenge explains;
  `httpErrorBlocks: false` reads such pages anyway). A job that reads several
  pages (a search, then a product) calls `open` for each.
- **One result shape** (`ScrapeResult`): `shop`, `url` (after redirects),
  `title`, `price` (a number; `parsePrice` reads "38.990 Ft" or "1.234,56 €"),
  `currency` (ISO 4217), `image`, `source`.
- **Errors that say which shop and why** (`ScraperError`: `shop`, `reason`,
  `status`, `detail`): "amazon.de: the shop answered with an HTTP error (HTTP
  503)". `isScraperError(e, reason)` holds across the ESM and CommonJS builds.

**The bundled Chromium.** At build time, `stageBundledChromium({ target })`
stages the build the pinned `playwright-core` expects (`chromiumBuild()`) into
the folder the installer carries as `resources/ms-playwright`, copied from
Playwright's per-user cache; it downloads nothing itself (pass the app's own
`download` for a machine whose cache lacks it). At start, the packaged app
calls `useBundledChromium(folder)` before its first scrape. The bundled build
is for a headed browser (headless needs Playwright's separate headless shell).

## Updates (`desktop-kit/update`, `desktop-kit/update/server`)

From APPS.PLAN (the user's picks: Electron, desktop-kit grown in place; the feed private, behind each app's own
Vercel site). Three pieces: the app asks its site, the site answers only its owner, the build writes the feed.

**In the app** (main process). electron-updater is the app's own dependency, passed in as Electron is:

```ts
import { autoUpdater } from 'electron-updater';
import { createUpdater } from 'desktop-kit/update';

const updates = createUpdater({
  updater: autoUpdater,
  feedUrl: 'https://smakmal.example/api/updates',
  currentVersion: app.getVersion(),
  token: async () => (await auth.currentUser?.getIdToken()) ?? null, // fresh each time; null when signed out
  ask: async ({ version, manual }) =>
    (await dialog.showMessageBox({ message: `${manual ? 'A newer version is available' : 'Update available'}: ${version}`, buttons: [manual ? 'Open the download page' : 'Download', 'Not now'] })).response === 0,
  downloadPage: 'https://smakmal.example/download', // macOS
  openExternal: (url) => shell.openExternal(url),
  log,
});
updates.start(); // 15 s after start, then once a day; updates.check() for a menu's "Check for updates"
```

- **Never without the user**: nothing downloads until `ask` says yes (`autoDownload` off); a version the user
  declined is not offered again until the app starts again; a newer one is.
- **Installed when the app quits, never sooner** (`autoInstallOnAppQuit`): the kit never calls `quitAndInstall`, so
  the app never restarts by itself. The new version's first run is a fresh unsigned executable, so on a machine
  with Defender's prevalence rule it is audited then, when the user expects a change.
- **The token on every request**: the signed-in owner's Firebase ID token in `Authorization`, fetched again before
  the download (the question may outlast it). No token is kept on the PC; signed out, nothing is asked.
- **One request per range** (`useMultipleRangeRequest: false`): differential downloads (the blockmap) against
  storage that need not answer multi-range requests; a failed differential download falls back to the full one.
- **The state** (`onState`, `updates.state`): `checking`, `signed-out`, `up-to-date`, `available` (asking),
  `declined`, `downloading` (with its percent), `ready` (installs on quit), `newer-available` (macOS), `error` (the
  message with any token taken out).
- **The app's log** (`log`): the kit's own lines and electron-updater's own messages (its `logger` pointed at the
  app's log, each prefixed `electron-updater:`, any token taken out), so a differential download that fell back to
  the full one shows there. Without `log`, electron-updater keeps writing to the console.
- **macOS**: an unsigned app cannot update itself there (Squirrel.Mac needs signing). The kit reads
  `<channel>-mac.yml` itself, with the token, and on a newer version asks; yes opens the download page.

**On the site** (`desktop-kit/update/server`), e.g. `api/updates/[file].ts` on Vercel, with firebase-admin:

```ts
import { createFeedHandler, nodeFeedHandler } from 'desktop-kit/update/server';

const feed = createFeedHandler({
  verifyIdToken: (t) => getAuth().verifyIdToken(t),
  owners: { uids: [process.env.OWNER_UID!] },
  signedUrl: async (file) => {
    const f = getStorage().bucket().file(`updates/${file}`);
    if (!(await f.exists())[0]) return null;
    return (await f.getSignedUrl({ action: 'read', expires: Date.now() + 5 * 60_000 }))[0];
  },
});
export default nodeFeedHandler(feed); // Express: app.get('/api/updates/:file', nodeFeedHandler(feed, (req) => req.params.file))
```

GET or HEAD of a feed file (`<channel>.yml`, the installer, its `.blockmap`, a `.dmg` or `.zip`; no folders, no
`..`): no token is 401, a token Firebase refuses is 401, anyone but an owner (by user id, or a verified e-mail) is
403, an owner gets a 302 to the file's short-lived link, `Cache-Control: private, no-store`. A failed storage
call, or any other throw in the listener (a failing `fileOf`), is a 500 `Try again later` with no detail; the error
goes to the handler's `log` (the console without one), the response is always ended and the server keeps serving
(`nodeFeedHandler` returns a listener that returns nothing, so no promise reaches Node or Express). electron-updater
follows that redirect and drops the token on the way to another origin (`authorization` and cookies are stripped
on a cross-origin redirect), so the storage never sees it. Checked on 2026-11-16 with Electron 45.0.0 and
electron-updater 6.8.11 against stand-in servers on 127.0.0.1: `latest.yml`, the blockmap and the installer each
redirected, the token at the site every time and never at the storage.

**In the build** (`desktop-kit/packaging`). `buildInstaller({ ..., update: { url, channel } })` gives
electron-builder the generic feed (it writes `<channel>.yml`, the installer's `.blockmap` and the app's
`app-update.yml`; `publish: 'never'` keeps it from uploading). Then:

```ts
import { collectFeed } from 'desktop-kit/packaging';
const { version, files } = collectFeed({ buildDir, outDir: path.join(projectDir, 'release-feed', version) });
```

It copies `latest.yml`, the installer and its blockmap into `outDir` under versioned names ("SmakMal-Setup.exe"
becomes "SmakMal-Setup-0.2.0.exe", the yml rewritten to match): electron-updater finds the previous version's
blockmap by putting the old version into the new name, so a name without its version would compare the installer
with itself. Each file is checked against the yml's sha512 and size. **It uploads nothing: the upload is the
user's step.** Copy the folder's files into the app's private storage under `updates/`, keeping the earlier
versions' installers and blockmaps there (the differential download reads the previous blockmap), and
`latest.yml` last, so no PC is offered a version whose installer is not there yet.

**Unsigned, by the user's decision (2026-10-22).** With no `publisherName`, electron-updater verifies no signature,
and electron-builder 26 installs updates it has not verified: **the feed's HTTPS and the owner check are the only
protection**. electron-builder 27 adds an Ed25519-signed update manifest (not Windows code signing), but it also
removes `ELECTRON_BUILDER_7ZIP_PATH`, the only way to hand it the installed 7-Zip 26.03+; so the kit builds with 26
only (`assertElectronBuilder26`, in every `buildInstaller`), and the apps pin `"electron-builder": "^26"`. When the
manifest is taken up: **once an app has shipped a signed manifest it must never drop it**, since installs holding
the key refuse an unsigned one.

## The local service (`desktop-kit/service`)

From CHROME.SERVICE (the user's answer: the service runs on the mini PC and on his own PC, and one of them holds
each app's lease at a time, CHROME.LEASE). A Chrome app (the web app on its Vercel site, open in Chrome) cannot scrape
a shop or run a job at four in the morning by itself; a small Node program on the PC does that for it, and the page
talks to it on `http://127.0.0.1:47380`. It is plain `node` running `bin/desktop-kit-service.mjs` from this
repository: no packaged exe and no installer (the unsigned-installer rule), so nothing to sign.

- **127.0.0.1 only.** It listens on 127.0.0.1 and nothing else (`0.0.0.0`, `::`, `localhost` and a `host` in the
  settings are refused before a socket opens), checks the address it got, and answers only a `Host` of
  `127.0.0.1:<port>` or `localhost:<port>`, so a DNS rebinding page is refused. It refuses to run with a Node
  inspector flag.
- **Services by name, each off until it is switched on.** Each app adds its own service (a module). The switch is
  per machine, in the user's profile, never in a repository. A service that is off is never imported, let alone
  started.
- **Two kinds.** `leased`: a timed job or a scraper, which runs only on the machine that holds the app's lease.
  `local`: answers on this PC only (such as the Claude route), never leased, and starts as soon as it is on.
- **CORS from a list.** Only the apps' own origins, from a list in the profile, and pages on `http://127.0.0.1` get
  CORS headers: the one origin is named, never `*`, and no credentials are allowed. Any other origin gets a 403
  without them.
- **No browser of its own.** A scraper goes through `desktop-kit/scraper` (Playwright over its pipe). Nothing here
  starts a browser with a debugging port or attaches to one over CDP.

### Setting it up on both machines

On the user's own PC, in the repository he works in:

```powershell
cd C:\git_personal\desktop-kit
npm ci
npm run build
node bin/desktop-kit-service.mjs autostart on
node bin/desktop-kit-service.mjs start
```

On the mini PC, from a git tag. There is no installer: a new version is a newer tag checked out and built.

```powershell
git clone https://github.com/zgyorkei/desktop-kit.git C:\desktop-kit
cd C:\desktop-kit
git checkout <tag>
npm ci
npm run build
node bin/desktop-kit-service.mjs autostart on
node bin/desktop-kit-service.mjs start
```

To move the mini PC to a newer tag:

```powershell
cd C:\desktop-kit
node bin/desktop-kit-service.mjs stop
git fetch --tags
git checkout <newer tag>
npm ci
npm run build
node bin/desktop-kit-service.mjs start
```

**At sign-in, the way Skuggbyrån's broker starts.** `autostart on` writes a shortcut in the user's Startup folder
(`%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\desktop-kit service.lnk`). It points to the installed
`node.exe` with `"<repository>\bin\desktop-kit-service.mjs" start`, runs minimised and works in the repository.
`start` runs the service in the background, with no window, and returns once it answers. `autostart off` removes
the shortcut and `autostart status` shows it. It needs no admin rights.

**Or a Task Scheduler entry** in place of the shortcut (one or the other, never both). A sign-in trigger usually
needs an elevated PowerShell to register:

```powershell
$node = (Get-Command node).Source
$action = New-ScheduledTaskAction -Execute $node -Argument '"C:\desktop-kit\bin\desktop-kit-service.mjs" start' -WorkingDirectory 'C:\desktop-kit'
$trigger = New-ScheduledTaskTrigger -AtLogOn -User $env:USERNAME
Register-ScheduledTask -TaskName 'desktop-kit service' -Action $action -Trigger $trigger
```

On the user's own PC the folder is `C:\git_personal\desktop-kit` instead.
`Unregister-ScheduledTask -TaskName 'desktop-kit service'` removes the entry.

### The switch and the services

The settings are one file in the profile, `%LOCALAPPDATA%\desktop-kit\service\service.json`. It is under Local, not
Roaming, because it belongs to this machine. `DESKTOP_KIT_SERVICE_HOME` moves the folder, and a folder inside a git
repository is refused. The first start writes the file with a new machine id, the computer's name, nothing
registered and nothing on. The log is `logs\service.log` in the same folder: it is rotated at about a megabyte, three
old files are kept, and anything that looks like a credential is redacted. Each service keeps its own files in
`data\<name>\`.

```json
{
  "machine": { "id": "5f0c1a2e-...", "name": "MINI-PC" },
  "port": 47380,
  "origins": ["https://lego-tracker.vercel.app"],
  "services": {
    "lt-prices": { "module": "C:\\git_personal\\lego-tracker\\service\\prices.mjs", "app": "lego-tracker", "kind": "leased", "on": true },
    "lt-claude": { "module": "C:\\git_personal\\lego-tracker\\service\\claude.mjs", "app": "lego-tracker", "kind": "local", "on": false }
  },
  "lease": "none"
}
```

A service is on only with `"on": true`. Any other value, a missing entry, or a module path that is not absolute
leaves it off (fail closed). An app's service is added once on each machine, and each machine switches it on or off
for itself:

```powershell
node bin/desktop-kit-service.mjs services add C:\git_personal\lego-tracker\service\prices.mjs
node bin/desktop-kit-service.mjs services on lt-prices
node bin/desktop-kit-service.mjs services list
node bin/desktop-kit-service.mjs services off lt-prices
```

`services add` imports the module to read its name, app and kind, without calling its `start`. It registers the
service off; `--on` switches it on at once. Each change tells a running service to read its settings again, and
`reload` also loads a module that changed on disk. The other commands are `run` (the service in the foreground),
`stop`, `status`, `reload`, `services remove <name>`, `log [lines]`, `where` and `help`.

### Origins, and Chrome's prompt

```powershell
node bin/desktop-kit-service.mjs origins add https://lego-tracker.vercel.app
```

An origin is https (plain http only on 127.0.0.1 or localhost, for a dev server), with no path and no wildcard, and
never `*` or `null`. Origins are compared parsed and exact, so `https://lego-tracker.vercel.app.evil.example` does
not match. A preview deployment has an origin of its own: add it while it is in use and remove it afterwards
(`origins remove`). Pages on `http://127.0.0.1` (any port) are always answered, since only a program on this PC can
serve one. A page may use GET, HEAD and POST with `Content-Type` and `Authorization` headers.

Chrome treats an https page calling `127.0.0.1` as a local network request. The service answers the preflight's
`Access-Control-Request-Private-Network` with `Access-Control-Allow-Private-Network: true`, and newer Chrome versions
also ask the user once per site for local network access. Allow it for the app's site. A refused prompt shows in the
page as a failed fetch, and is undone in the site's settings in Chrome.

```ts
const r = await fetch('http://127.0.0.1:47380/health?app=lego-tracker');
const health = await r.json();
if (health.app.holdsLease) {
  // this PC runs lego-tracker's timed jobs and scrapers
}
```

### The health route

`GET /health`, or `HEAD`; any other method gets a 405. It holds no secrets: no token, no settings, no module
paths, no origins and no folders of the PC. A failed service's error is redacted, with paths replaced by `<path>`.

```json
{
  "ok": true,
  "service": "desktop-kit-service",
  "version": "0.1.0",
  "machine": { "id": "5f0c1a2e-...", "name": "MINI-PC" },
  "startedAt": "2026-11-20T06:00:00.000Z",
  "lease": { "mode": "solo", "apps": { "lego-tracker": { "holds": true, "holder": { "id": "5f0c1a2e-...", "name": "MINI-PC" } } } },
  "services": [{ "name": "lt-prices", "app": "lego-tracker", "kind": "leased", "state": "running", "since": "2026-11-20T06:00:01.000Z" }],
  "app": { "name": "lego-tracker", "holdsLease": true, "holder": { "id": "5f0c1a2e-...", "name": "MINI-PC" } }
}
```

`app` is there with `?app=<name>`; with the shared lease it also carries `expiresAt`. A service's `state` is one of:

- `off`;
- `waiting`: on and leased, with the lease held elsewhere or not known;
- `starting`, `running` or `stopping`;
- `failed`: tried again on the next `reload`.

`/services/<name>/...` reaches a running service's own routes; while the service is not running it answers 503 with
the state. `/control/stop` and `/control/reload` are for the CLI only. They take POST only, need the token from
`control.json` (in the profile folder, written at each start), and refuse any request from a page (one with an
`Origin` or `Sec-Fetch-Site` header).

### Writing a service

The app's module default-exports its definition (`defineService` only checks it; a plain object works too). Its top
level only defines, because it is imported only while the service is on; the work starts in `start`:

```js
// lego-tracker/service/prices.mjs
import path from 'node:path';
import { defineService } from 'desktop-kit/service';
import { Scraper } from 'desktop-kit/scraper';

export default defineService({
  name: 'lt-prices',
  app: 'lego-tracker',
  kind: 'leased',
  description: 'the daily price check',
  start(ctx) {
    const scraper = new Scraper({ profileRoot: path.join(ctx.dataDir, 'browser') });
    let last = null;
    ctx.daily('04:00', async () => {
      last = await scraper.scrape('https://shop.example/set/10497', ({ page }) => page.evaluate(() => document.title));
    }, { name: 'prices' });
    return {
      stop: () => scraper.close(),
      // GET http://127.0.0.1:47380/services/lt-prices/last
      http: (req, res, next) => {
        if (req.method !== 'GET' || req.url !== '/last') return next();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(last));
      },
    };
  },
});
```

The context gives:

- `name`, `app`, `kind` and `machine`;
- `log`: the service's lines in the service's log;
- `signal`: aborted when the service stops;
- `dataDir`: a folder of its own in the profile;
- `every(ms, job, { name })`: at least a second apart, never two runs at once. A leased service's `every` runs at
  least a minute apart, once per interval of the clock (the same intervals on both machines), and claims each
  interval's run through the lease first;
- `daily('HH:MM', job, { name })`: once a day at or after that local time, also on the first check after the PC
  wakes past it. A leased service claims each day's run through the lease first, so a hand-over between the machines
  runs it once. The day is marked before the run, so a failed run waits for the next day instead of looping.

A job's name (lower case letters, digits and hyphens) defaults to `every-<ms>` or `daily-HHMM`; a leased service
names its jobs when it has two of one kind, since the name is part of the run's record.

A service stops when it is switched off, when its lease goes, or when the service stops: `signal` aborts, its timers
end and its `stop` is called.

### The lease

The `lease` setting decides where the leased services run:

- `"none"` (the default): no lease, so no leased service runs here (fail closed). Local services still run.
- `"solo"`: this machine always holds every app's lease. Use it on one machine only: two machines on solo would both
  run the jobs.
- `{ "firestore": { "preferred": true, "apps": { ... } } }`: the shared lease (CHROME.LEASE, below). One machine
  at a time holds each app's lease, the mini PC preferred. This is the setting for the mini PC and the user's PC.
- `{ "module": "<absolute path>" }`: a lease module of its own. The module exports
  `createLease({ machine, log, dataDir })`, which returns a `Lease` with `state(app)` (never throws, never waits),
  `want(app)`, `release(app)`, `claimRun(app, job, slot)`, `onChange(listener)` and `close()`. If the module fails
  to load there is no lease, and a lease whose state cannot be read counts as not held.

```powershell
node bin/desktop-kit-service.mjs lease
node bin/desktop-kit-service.mjs lease solo
node bin/desktop-kit-service.mjs lease firestore
node bin/desktop-kit-service.mjs lease module <the lease module's absolute path>
node bin/desktop-kit-service.mjs lease none
```

`lease` alone shows the setting. When an app's lease moves to the other machine, this one stops the app's leased
services and they wait. Local services are not touched.

### The shared lease (Firestore)

From CHROME.LEASE. The leased services (timed jobs, scrapers) run on the mini PC and on the user's PC, on one of
them at a time. Each app's lease is one Firestore document, `leases/<app>`, in the app's own Firebase project:

```json
{ "holder": "5f0c1a2e-...", "name": "MINI-PC", "preferred": true, "expiresAt": "2026-11-20T06:03:00Z",
  "writtenAt": "2026-11-20T06:00:00Z", "wantedBy": null, "wantedName": null, "wantedAt": null }
```

- **One winner.** A machine that finds the lease free or run out takes it with a compare-and-set: a Firestore
  commit that holds only if the document is still the version it read (or still missing). Of two machines starting
  together exactly one wins; the other reads the winner and waits.
- **Three minutes, renewed each minute.** A hold lasts 3 minutes and the holder renews it every 60 seconds. The
  holder stops its leased services 15 seconds before its hold runs out if it could not renew, and another machine
  takes a lease only 15 seconds after it ran out, so the two never overlap even with clocks a few seconds apart.
- **No stealing.** A live lease is never taken, by either machine.
- **The mini PC is preferred** (`lease preferred on`, on the mini PC only). When the user's PC holds the lease, the
  mini PC writes an ask into the document (`wantedBy`) and renews it each minute. The user's PC sees the ask at its
  next renewal, stops the app's leased services (each `stop` is waited for, up to a minute), and then frees the
  lease, keeping the ask; the mini PC, which looks every 20 seconds while it asks, takes it. While a fresh ask is
  there, the user's PC does not take a free lease either. So the user's PC runs the jobs only while the mini PC is
  off, asleep or cut off.
- **Switched off, let go.** When the user switches an app's last leased service off on a machine (or removes the
  app from the shared lease, or stops the service), that machine frees the lease at once instead of letting it run
  out.
- **Local services are never leased**; they start as soon as they are on, with or without Firestore.

**Each run once.** A leased timed job claims its run first: one document per run,
`jobs/<app>/<service>.<job>/<slot>`, where the slot is the day (`2026-11-20`) for `daily` and the interval's start
(`2026-11-20T060000.000Z`) for `every`. The document is created once, so a run is never made twice: not after a
hand-over, not when both machines wake past 04:00. It is written `running`, then `done` or `failed`. A failed run may
be claimed once more (by the next machine that holds the lease, or the next interval's check), two attempts in all;
a run that is still `running` (its machine crashed or went to sleep in it) is never made again, since it may have
done its work.

**Fail closed.** With Firestore unreachable (no network, a refused sign-in, a missing database), a leased service
does not start, and a running one keeps running only until its hold runs out (less the 15 seconds), then stops.
Nothing runs on a guess. The log says so once, and once more when Firestore can be reached again; the lease is
tried again every 20 seconds.

**The health route** shows it (no project, no key, no path):

```json
"lease": { "mode": "firestore", "preferred": true, "apps": { "lego-tracker": {
  "holds": true, "holder": { "id": "5f0c1a2e-...", "name": "MINI-PC" }, "expiresAt": "2026-11-20T06:03:00.000Z", "role": "holder" } } },
"app": { "name": "lego-tracker", "holdsLease": true, "holder": { "id": "5f0c1a2e-...", "name": "MINI-PC" },
  "expiresAt": "2026-11-20T06:03:00.000Z", "role": "holder" }
```

This machine's `role` is one of:

- `holder`: it holds the lease and runs the app's leased services;
- `standby`: another machine holds it (`holder` and `expiresAt` say which and until when), or it is free and about
  to be taken;
- `asking`: the preferred machine has asked the holder for it back;
- `handing-back`: this machine is stopping its services to hand the lease to the preferred one;
- `unreachable`: Firestore cannot be reached, so nothing leased runs here (fail closed);
- `unconfigured`: the app has a leased service on but no Firebase project set here (`lease app add`);
- `off`: no leased service of the app is on here.

#### How Node signs in: a service account key in the profile

The service signs in to the app's own Firebase project as a **service account** made for this alone, with the
role Cloud Datastore User (`roles/datastore.user`): it reads and writes Firestore documents and can do nothing else in
the project. Its JSON key lives in the user's profile, `%LOCALAPPDATA%\desktop-kit\service\lease\keys\<app>.json`,
never in a repository, a package or a log: `lease app add` copies the key there, a key file inside a repository is
refused, and nothing prints or logs the key or a token (an error says only what Google or Firestore answered). The
key signs a short-lived token (an hour, Firestore's scope only), which is kept in memory only. No SDK and no new dependency: the
token is signed with `node:crypto` and Firestore is reached over its REST API.

Why not the user's own Google sign-in: its refresh token would reach everything the user can reach, would have to be
stored the same way, and is cut off by the user's password changes and Google's session policy, so the jobs would
stop without warning. A service account can do only Firestore in the app's project, and it can be revoked alone.

**The security rules need no change.** A service account signs in through Google Cloud's IAM, which Firestore's
security rules do not apply to; the rules apply to the app's web clients only. The web app's rules may keep denying
`leases/` and `jobs/` to every client (a rule that matches nothing already does).

**Setting it up** (once per app; lego-tracker as the example):

1. In the Google Cloud console for the app's Firebase project (the same project id), IAM and admin, Service
   accounts: create `desktop-kit-lease`, grant it Cloud Datastore User, then Keys, Add key, JSON. The key is
   downloaded once. If the organisation forbids key creation (`iam.disableServiceAccountKeyCreation`), the project's
   owner lifts it for this project.
2. On the mini PC, with the key file copied over (a USB stick, not a mail or a chat):

```powershell
node bin/desktop-kit-service.mjs lease app add lego-tracker <the downloaded key.json>
node bin/desktop-kit-service.mjs lease preferred on
```

3. On the user's PC, the same, without `preferred`:

```powershell
node bin/desktop-kit-service.mjs lease app add lego-tracker <the downloaded key.json>
```

4. Delete the downloaded key file on both machines (`lease app add` says so): the copy in the profile is the one in
   use. A running service follows each change at once.

`lease app add` takes the project from the key; `--project <id>` overrides it, and `--database <id>` names a database
other than `(default)`. Run again without the key file, it keeps the copy and changes only those. `lease app remove
<app>` takes the app out and deletes its key copy; `lease preferred off` makes a machine not preferred. A new key is
put in with `lease app add` again, after which the old one is deleted in the console. A lost or leaked key is deleted
in the console at once: that stops it everywhere.

**What it costs.** Per app, each machine reads the lease once a minute and the holder writes it once a minute: about
3,000 reads and 1,500 writes a day. A claimed run costs two reads and two writes, so an hourly job adds about 50 of
each. This is well inside Firestore's free quota (50,000 reads and 20,000 writes a day).

## A new app (`desktop-kit create`)

From APPS.TEMPLATE. The user: "any future application made as a proper application". Every new app of the user's
own starts from `template/`, the layout SmakMal already has:

- the web app at the root, Vite and React with react-router, on its Vercel site, with its server routes in `api/`
  (`lib/api.ts`, shared with the dev server `server.ts`);
- the PWA from pwa-kit (`pwa.config.ts`, `src/sw.ts`): installed from Chrome as an app window on the PC and on the
  phone's home screen, updating itself, with pwa-kit's navigation (a bar under 600 px, a rail from 600, the expanded
  rail from 1200) and quick actions;
- Firestore and Google sign-in through `desktop-kit/sync`, with the rules template (`firestore.rules`) and a small
  example collection (notes);
- the local service's modules in `service/`: a leased daily job and a local service whose key comes from an
  environment variable the user sets;
- a fixed loopback port of its own (below, "Ports"), and secrets read at run time, never built into the page.

On a PC the app follows "The standard: the Chrome app matches the desktop app" (below): `npm run app` opens it in a
1400 x 900 window in the desktop layout. The stack is the user's pick for the starter after APPS.CHROME.PLAN (a PWA
on pwa-kit plus the local service), so it has no Electron of its own.

From this folder, once the kit is built:

```powershell
node bin/desktop-kit.mjs create brick-notes C:\git_personal\brick-notes
```

Where the kit is a dependency, `npx --no desktop-kit create <name> [folder]` runs the same bin (`--no` keeps npx
from installing anything). The options: `--title "<title>"` (by default from the name), `--port <port>` (by default
the next free one below), `--pwa-kit <dir>` (pwa-kit's checkout; by default `PWA_KIT_DIR`, else `pwa-kit` beside
this folder) and `--no-kits`. The name is lower case letters, digits and hyphens, at most 42, and the folder is made
if missing and refused unless empty.

It copies `template/` with `__APP_NAME__`, `__APP_TITLE__`, `__APP_PORT__` and `__APP_ENV__` filled in, in the files
and their names (`gitignore` becomes `.gitignore` and `env.example` becomes `.env.example`: npm pack drops the one
and this repository's `.gitignore` keeps out the other). Then the kits step packs this kit and pwa-kit into the
app's `vendor/` (the app's `scripts/kits-refresh.mjs`) and points its `package.json` at the tarballs. **Temporary:**
until DK.RELEASE tags the kits, the app pins them as `file:vendor/...` tarballs; after it, the tags. It prints the
next steps; the new app's README holds the person's setup (the Firebase project, the Vercel project and its
variables, the sign-in domains, the first install, the local service on each PC).

The kit's tests make an app from the template (`test/create.test.ts`); `template/` itself is kept out of the kit's
type check and `npm test`, since its code needs the app's own packages.

## Ports

Each app has a fixed port on 127.0.0.1 for its dev server and preview, so its origin (the browser's storage, the
installed app, the local service's origins) never moves. `desktop-kit create` gives a new app the next free port from
47341 in steps of 10, reading this table, and prints the row to add here.

| App | Port |
| --- | --- |
| Brick Tracker | 47321 |
| SmakMal | 47331 |
| desktop-kit service | 47380 |

## Building and testing

ESM and CommonJS builds with their types, by tsup, for Node 22.

```sh
npm install
npm run build       # dist/
npm run dev         # rebuilds on every change, while an app links the kit
npm test            # builds first, then runs the tests (vitest)
npm run typecheck
npm run test:browser # the scraper in the installed Edge, against pages served on 127.0.0.1
```

The tests also load the built package by its name from CommonJS and from ESM,
so a broken export map fails them. `npm test` starts no browser; the browser
tests (`test/browser/`) start the installed Edge headless through Playwright's
pipe, never through a debugging port.

## Linking it from an app

**While it is developed**, the app's desktop package depends on the sibling
folder, and `npm run build` (or `npm run dev`) here keeps `dist/` current:

```json
"desktop-kit": "file:../../desktop-kit"
```

That is the path from `lego-tracker/desktop` (and from a `smakmal/desktop`
package); from budget-tracker, whose root package is the desktop app, it is
`file:../desktop-kit`. npm links the folder, so a rebuild here is seen at once.

**After DK.RELEASE**, the app pins the GitHub release tag's tarball, as
lego-tracker pins shop-teacher:

```json
"desktop-kit": "https://github.com/zgyorkei/desktop-kit/archive/refs/tags/v0.1.0.tar.gz"
```

The tarball needs no git and no SSH key, and the lockfile pins its checksum.
`dist/` is not committed here (`.gitignore`), and a tag's source archive holds
only what is committed, so DK.RELEASE decides how the release carries the
build: `dist/` committed at the release tag, as shop-teacher does, or the
`npm pack` tarball attached to the GitHub release and pinned by its URL.

## Secrets

Never committed: `.env` files, `oauth-client.json`, `app-config.json` and
`google-session.bin` are in `.gitignore`. An app keeps its own.

## The standard: the Chrome app matches the desktop app

The user, 2026-11-23: "do the same for lego tracker and smakmal, and this should be standard for all future developments for my own applications". On a PC, each of the user's own Chrome apps acts exactly like its desktop app, in looks and in function. The desktop layout shows in a PC-sized window; the phone keeps its own layout.

What a browser cannot do runs in the local service and its tray. Any key the service needs comes from an environment variable the user sets, never from an OS key store. Links to other sites open in a Chrome tab.

Every new app, and every change to an app, for the user's own applications is checked against this standard. Where a desktop feature has no Chrome counterpart yet, the work writes a parity page like the BrickBudget one (CHROME-BT-PARITY-2026-11-23.html, in the orchestrator's reports folder), and every gap becomes a work item after the item it extends.
