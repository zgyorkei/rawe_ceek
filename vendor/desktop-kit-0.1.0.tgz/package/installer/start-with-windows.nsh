; desktop-kit's NSIS include (buildInstaller's startWithWindows): start with Windows, hidden, on a fresh install.
;
; The Run value is the one Electron's app.setLoginItemSettings writes (electron.app.<productName>, with --hidden),
; so the app's own "Start with Windows" toggle (desktop-kit/shell setStartWithWindows) sees and changes this entry.
; Only a fresh install adds it: over an existing copy (an upgrade) the user's choice is left alone. An app with its
; own include can !include this file from it.

; The uninstaller is compiled from this file too, and never uses the variable; NSIS treats that as an error.
!ifndef BUILD_UNINSTALLER
  Var desktopKitWasInstalled
!endif

!macro customInit
  ; After initMultiUser, so $INSTDIR is the install folder; before any file is written, so the app's exe there
  ; means an earlier install.
  StrCpy $desktopKitWasInstalled "0"
  ${if} ${FileExists} "$INSTDIR\${APP_EXECUTABLE_FILENAME}"
    StrCpy $desktopKitWasInstalled "1"
  ${endif}
!macroend

!macro customInstall
  ${if} $desktopKitWasInstalled == "0"
    WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "electron.app.${PRODUCT_NAME}" '"$INSTDIR\${APP_EXECUTABLE_FILENAME}" --hidden'
  ${endif}
!macroend

; A newer installer runs the old uninstaller with --updated first; only a real uninstall removes the entry. The
; data folder is kept either way.
!macro customUnInstall
  ${ifNot} ${isUpdated}
    DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "electron.app.${PRODUCT_NAME}"
  ${endif}
!macroend
