; desktop-kit's NSIS include for an assisted installer that also starts the app with Windows (buildInstaller's
; installer: 'assisted' with startWithWindows): both of the kit's includes, from this file's own folder.

!include "${__FILEDIR__}\assisted.nsh"
!include "${__FILEDIR__}\start-with-windows.nsh"
