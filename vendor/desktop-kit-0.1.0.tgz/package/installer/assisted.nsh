; desktop-kit's NSIS include for the assisted installer (buildInstaller's installer: 'assisted'). electron-builder's
; assisted installer has no welcome page of its own, and its finish page's "Run <app>" box starts ticked; this adds
; the welcome page and leaves the box unticked, so the app starts after setup only when the user ticks it. An app
; with its own include can !include this file from it.

!ifndef BUILD_UNINSTALLER
  ; read by MUI2's finish page, which electron-builder inserts after this file is included
  !define MUI_FINISHPAGE_RUN_NOTCHECKED
!endif

; electron-builder inserts this macro, when it is defined, as the installer's first page
!macro customWelcomePage
  !insertmacro MUI_PAGE_WELCOME
!macroend
